package practice;

public class CookieOrder {
	public String getVariety() {
		return null;
	}
	public String getNumBoxes() {
		return null;
	}

}
