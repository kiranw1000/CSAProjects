package zoo;

import java.util.ArrayList;

public class ZooRunner {
	/*public static void main(String[] args) {
		ArrayList<Animal> myZoo = new ArrayList<Animal>();
		myZoo.add(new Animal("a1","WATER","MALE",2));
		myZoo.add(new Penguin("Happy Feet","LAND","MALE",4,true));
		myZoo.add(new RockHopper("Happy Feet 2","LAND","MALE",false));
		myZoo.add(new Dragon("Drago","MALE","LARGE"));
		myZoo.add(new Animal());
		myZoo.add(new Penguin());
		myZoo.add(new RockHopper());
		myZoo.add(new Dragon());
		for(Animal a : myZoo) {
			System.out.println("Zoo inhabitant is:");
			System.out.println(a);
			System.out.println("I make this sound: " + a.makeSound());
			System.out.println("I move this way: "+ a.move());
			if(a instanceof Penguin) {
				Penguin b = (Penguin) a;
				System.out.println(b.swim());
			}
		}
	}*/
}
