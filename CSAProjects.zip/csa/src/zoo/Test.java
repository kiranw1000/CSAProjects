package zoo;

public class Test extends Animal {

}
