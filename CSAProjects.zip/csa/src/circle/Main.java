package circle;

public class Main {

	public static void main(String[] args) {
		Circle sphere = new Circle(2.5);
		System.out.println(sphere);
		System.out.println(sphere.area());
	}

}
