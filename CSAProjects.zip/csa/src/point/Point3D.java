package point;

public class Point3D extends Point {
	int ht;
	public Point3D(){
		//super(0,0);
		ht = 0;
	}
}
